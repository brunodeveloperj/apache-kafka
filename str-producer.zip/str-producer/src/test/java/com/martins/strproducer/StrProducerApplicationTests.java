package com.martins.strproducer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StrProducerApplicationTests {

	@Test
	void contextLoads() {
	}

}
